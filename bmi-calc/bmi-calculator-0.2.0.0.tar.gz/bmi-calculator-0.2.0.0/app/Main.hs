{-# LANGUAGE ScopedTypeVariables #-}
module Main  (main)  where

import Text.Printf ( printf )


bmiTell :: Double -> Double -> String
bmiTell wgt hgt
    | bmi <= skinny = "Olet alipainoinen rääpäle!"
    | bmi <= normal = "You're supposedly normal. Pffft, I bet you're ugly!"
    | bmi <= fat = "You're fat! Lose some weight, fatty!"
    | otherwise   = "You're a whale, congratulations!"
  where bmi = wgt / hgt / hgt
        (skinny, normal, fat) = (18.5, 25.0, 30.0)


colorTell :: (Ord a, Fractional a) => a -> String
colorTell bmi
    | bmi <= skinny = blue
    | bmi <= normal = green
    | bmi <= fat = red
    | otherwise   = yellow
  where (skinny, normal, fat) = (18.5, 25.0, 30.0)
        (blue, green, red, yellow) = ("\ESC[94m","\ESC[92m","\ESC[91m","\ESC[93m" )


bmiValue :: Fractional a => a -> a -> a
bmiValue wgt hgt =
    wgt / hgt / hgt


main :: IO ()
main = do
          print    "Input weight KG "
          w :: Double <- readLn
          print "Input height CM"
          hCM :: Double <- readLn
          let h = 0.01 * hCM
          putStrLn "\ESC[2J BMI-CALCULATOR"
          printf "   Weight: %4.2f kg Height: %4.2f m"  w h
          putStrLn "\n"
          printf "   Your BMI value is %4.2f " (bmiValue w h)
          putStrLn "\n"
          putStrLn $   colorTell (bmiValue w h) ++ bmiTell w h
          putStrLn  "\ESC[97m_________\ESC[0m"
